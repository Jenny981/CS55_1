import json
import tempfile
import unittest
from pathlib import Path

import fitz
import numpy as np

from cs55_demo.automatic import allowed_evidence, validate_ranges, select_top1, extract_automatic_panels, rerank_with_text
from cs55_demo.system import load_config, retrieve, apply_reviews, save_json, _scores


class FakeEncoder:
    def images(self, records):
        return np.array([r["test_vector"] for r in records]) if records else np.empty((0, 2))

    def texts(self, descriptions):
        return np.array([[1., 0.] for _ in descriptions])


class WorkflowTests(unittest.TestCase):
    def test_text_changes_choice_only_for_close_visual_candidates(self):
        rows = [dict(id="a", evidence_index=1, visual_rank=1, visual_similarity=.80,
                     text_group_id="a", text_group_rank=2, declared_range_ids=[1]),
                dict(id="b", evidence_index=2, visual_rank=2, visual_similarity=.79,
                     text_group_id="b", text_group_rank=1, declared_range_ids=[1])]
        ranked = rerank_with_text(rows, {})
        self.assertEqual(ranked[0]["id"], "b")
        self.assertTrue(ranked[0]["text_reranking_applied"])
        choice = select_top1(ranked, dict(acceptance_mode="range_top1", min_visual_similarity=.25))
        self.assertEqual(choice["selected_candidate_id"], "b")
        rows[1]["visual_similarity"] = .5
        self.assertEqual(rerank_with_text(rows, {})[0]["id"], "a")

    def test_range_mode_does_not_require_manual_acceptance_for_ambiguity(self):
        rows = [dict(id="a", evidence_index=1, visual_rank=1, visual_similarity=.8,
                     declared_range_ids=[1], runner_up_visual_similarity=.799)]
        settings = dict(acceptance_mode="range_top1", min_visual_similarity=.25,
                        min_top1_margin=.02, require_auxiliary_support=True)
        self.assertEqual(select_top1(rows, settings)["status"], "provisionally_matched")
        settings["acceptance_mode"] = "strict"
        self.assertEqual(select_top1(rows, settings)["status"], "requires_review")

    def test_range_boundaries_and_union(self):
        ranges = [dict(evidence_type="storyboard", panel_indices=[1], final_start_sec=2, final_end_sec=4),
                  dict(evidence_type="storyboard", panel_indices=[3], final_start_sec=3, final_end_sec=5)]
        evidence = [dict(evidence_index=i) for i in (1, 2, 3)]
        validate_ranges(ranges)
        self.assertEqual(set(allowed_evidence(dict(timestamp_sec=3), evidence, "storyboard", ranges)), {0, 2})
        self.assertEqual(set(allowed_evidence(dict(timestamp_sec=4), evidence, "storyboard", ranges)), {2})
        self.assertEqual(allowed_evidence(dict(timestamp_sec=5), evidence, "storyboard", ranges), {})
        with self.assertRaises(ValueError):
            validate_ranges([dict(evidence_type="animatic", final_start_sec=0, final_end_sec=1,
                                  evidence_start_sec=2, evidence_end_sec=1)])

    def test_top1_cannot_pass_by_rank_alone(self):
        settings = dict(min_visual_similarity=.5, min_top1_margin=.1, require_auxiliary_support=True)
        rows = [dict(id="one", evidence_index=1, visual_similarity=.9, text_supported=False,
                     declared_range_ids=[1])]
        self.assertEqual(select_top1(rows, settings)["status"], "requires_review")
        rows[0].update(text_supported=True, runner_up_visual_similarity=.85)
        self.assertEqual(select_top1(rows, settings)["reason"], "top1_top2_ambiguous")
        rows[0]["runner_up_visual_similarity"] = .6
        self.assertEqual(select_top1(rows, settings)["status"], "provisionally_matched")

    def test_automatic_panel_filter_handles_empty_page(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with fitz.open() as doc:
                doc.new_page()
                doc.save(root / "empty.pdf")
            records, manifest = extract_automatic_panels(root / "empty.pdf", root / "panels")
            self.assertEqual(records, [])
            self.assertEqual(manifest["pages"][0]["extraction_status"], "not_extracted")

    def test_retrieval_range_excludes_stronger_outside_candidate_and_keeps_denominator(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config_path = root / "config.json"
            save_json(config_path, dict(matching=dict(use_structure=False, top_k=1),
                correspondence_ranges=[dict(evidence_type="storyboard", panel_indices=[2],
                                           final_start_sec=0, final_end_sec=2)]))
            config = load_config(config_path)
            frames = [dict(timestamp_sec=t, keyframe_path=f"final{t}.png", test_vector=[1., 0.])
                      for t in (0., 1., 2.)]
            panels = [dict(evidence_index=i, panel_path=f"panel{i}.png", test_vector=v,
                           text=dict(description="A shared action", text_group_id="shared",
                                     shared_panel_count=2))
                      for i, v in ((1, [1., 0.]), (2, [.7, .714]))]
            prepared = dict(run_dir=str(root), panels=panels, frames=dict(final=frames, animatic=[]))
            save_json(root / "prepared.json", prepared)
            result = retrieve(config, prepared, encoder=FakeEncoder(), progress=lambda _: None)
            self.assertTrue(result["candidates"])
            self.assertTrue(all(r["evidence_index"] == 2 for r in result["candidates"]))
            scores = json.loads((root / "evidence_scores.json").read_text())
            self.assertEqual(scores["provisional_and_human"]["total_final_frames"], 3)
            self.assertEqual(scores["provisional_and_human"]["visual_support_score"], 66.67)
            self.assertEqual(scores["human_confirmed"]["visual_support_score"], 0)
            reviews = [dict(route="final_storyboard", final_index=1, decision="unmatched")]
            apply_reviews(root, reviews)
            self.assertEqual(len(json.loads((root / "matched_list.json").read_text())), 1)
            with self.assertRaises(ValueError):
                apply_reviews(root, [dict(route="final_storyboard", final_index=1,
                                         decision="matched", candidate_id="final_storyboard:2:2")])

    def test_sequence_can_observe_reverse_order(self):
        rows = [dict(route="final_animatic", final_index=i, evidence_index=j)
                for i, j in enumerate((3, 2, 1), 1)]
        score = _scores([{}, {}, {}], rows)
        route = next(r for r in score["route_order"] if r["route"] == "final_animatic")
        self.assertEqual(route["discordant_pair_count"], 3)
        self.assertEqual(route["score"], 0)


if __name__ == "__main__":
    unittest.main()

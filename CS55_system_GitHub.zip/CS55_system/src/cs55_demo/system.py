"""Portable notebook and CLI entry points for the same evaluation pipeline."""
import json
from pathlib import Path
from datetime import datetime, timezone

import numpy as np

from .automatic import extract_automatic_panels, validate_ranges, allowed_evidence, select_top1, rerank_with_text
from .sampling import extract_time_samples
from .storyboard_text import extract_panel_descriptions, annotate_shared_text_groups
from .provenance import inspect_asset_basics, collect_project_file_evidence, build_editing_history, build_provenance_summary
from .provenance_scoring import provenance_scores, timestamp_comparisons


def save_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    temp.replace(path)


def load_config(path):
    path = Path(path).resolve()
    config = json.loads(path.read_text(encoding="utf-8"))
    for field in ("final_path", "storyboard_path", "animatic_path", "output_dir", "project_search_root"):
        if config.get(field):
            value = Path(config[field]).expanduser()
            config[field] = str(value if value.is_absolute() else (path.parent / value).resolve())
    for field in ("source_project_paths", "source_project_unsigned_paths"):
        config[field] = {role: str((path.parent / value).resolve())
                         for role, value in config.get(field, {}).items()}
    validate_ranges(config.get("correspondence_ranges", []))
    settings = config.setdefault("matching", {})
    defaults = dict(top_k=5, min_visual_similarity=.25, min_top1_margin=.02,
                    require_auxiliary_support=True, require_declared_ranges=True,
                    text_top_k=10, structure_top_k=10, structure_candidate_limit=20,
                    neighbor_radius=2, max_consecutive=5, use_structure=True,
                    acceptance_mode="range_top1", use_text_reranking=True,
                    text_visual_shortlist=5, text_max_visual_loss=.05, text_rank_weight=1.25)
    for key, value in defaults.items():
        settings.setdefault(key, value)
    if settings["acceptance_mode"] not in ("range_top1", "strict"):
        raise ValueError("Unknown acceptance mode")
    for key in ("top_k", "text_top_k", "structure_top_k", "structure_candidate_limit", "max_consecutive"):
        if type(settings[key]) is not int or settings[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    if type(settings["neighbor_radius"]) is not int or settings["neighbor_radius"] < 0:
        raise ValueError("neighbor_radius must be a nonnegative integer")
    for key in ("min_visual_similarity", "min_top1_margin"):
        if not np.isfinite(settings[key]) or settings[key] < 0:
            raise ValueError(f"Invalid {key}")
    return config


def prepare(config, progress=print):
    assets = {role: Path(config[f"{role}_path"]) for role in ("final", "animatic", "storyboard")
              if config.get(f"{role}_path")}
    if "final" not in assets or not ({"storyboard", "animatic"} & assets.keys()):
        raise ValueError("A Final and at least one evidence material are required")
    for path in assets.values():
        if not path.is_file():
            raise FileNotFoundError(path)
    run = Path(config.get("output_dir", "outputs")) / datetime.now(timezone.utc).strftime("run_%Y%m%dT%H%M%S_%fZ")
    run.mkdir(parents=True, exist_ok=False)
    save_json(run / "config.json", config)
    panels, manifest, text = [], None, []
    if "storyboard" in assets:
        progress("Automatically extracting usable Storyboard panels")
        panels, manifest = extract_automatic_panels(assets["storyboard"], run / "panels")
        # Full-document indices are assigned once, after quality filtering.
        text = extract_panel_descriptions(assets["storyboard"], panels) if panels else []
        for panel, item in zip(panels, text):
            item["storyboard_index"] = panel["evidence_index"]
        text = annotate_shared_text_groups(text)
        for record, item in zip(panels, text):
            record["text"] = item
        save_json(run / "panel_manifest.json", manifest)
        save_json(run / "panel_catalog.json", panels)
        save_json(run / "storyboard_text.json", text)
    frames = {}
    for role in ("final", "animatic"):
        if role not in assets:
            frames[role] = []
            continue
        progress(f"Sampling {role}")
        options = config.get("sampling", {}).get(role, {})
        table, _ = extract_time_samples(
            assets[role], run / "samples", role,
            interval_sec=options.get("interval_sec", 2.), start_sec=options.get("start_sec", 0.),
            end_sec=options.get("end_sec"), skip_near_blank=options.get("skip_near_blank", True))
        frames[role] = table.to_dict("records")
        for row in frames[role]:
            row["evidence_index"] = row["source_sample_index"]
        save_json(run / f"{role}_samples.json", frames[role])
    prepared = dict(run_dir=str(run), assets={k: str(v) for k, v in assets.items()},
                    panels=panels, frames=frames)
    save_json(run / "prepared.json", prepared)
    return prepared


class ClipEncoder:
    def __init__(self, model_name):
        import torch
        from transformers import CLIPModel, CLIPProcessor
        self.torch = torch
        self.device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
        self.model = CLIPModel.from_pretrained(model_name).to(self.device).eval()
        self.processor = CLIPProcessor.from_pretrained(model_name)

    def images(self, records):
        from PIL import Image
        import torch.nn.functional as F
        output = []
        for record in records:
            with Image.open(record.get("keyframe_path") or record["panel_path"]) as image:
                pixels = self.processor(images=image.convert("RGB"), return_tensors="pt")["pixel_values"]
            with self.torch.inference_mode():
                pooled = self.model.vision_model(pixel_values=pixels.to(self.device)).pooler_output
                features = self.model.visual_projection(pooled)
                output.append(F.normalize(features.float(), dim=-1).cpu().numpy()[0])
        return np.stack(output) if output else np.empty((0, self.model.config.projection_dim))

    def texts(self, descriptions):
        import torch.nn.functional as F
        output = []
        for start in range(0, len(descriptions), 32):
            inputs = self.processor(text=descriptions[start:start + 32], padding=True,
                                    truncation=True, return_tensors="pt")
            inputs = {k: v.to(self.device) for k, v in inputs.items()
                      if k in ("input_ids", "attention_mask")}
            with self.torch.inference_mode():
                pooled = self.model.text_model(**inputs).pooler_output
                features = self.model.text_projection(pooled)
                output.extend(F.normalize(features.float(), dim=-1).cpu().numpy())
        return np.stack(output) if output else np.empty((0, self.model.config.projection_dim))


def retrieve(config, prepared, encoder=None, progress=print):
    """Rank within supplied ranges; do not impose an ordered matching path."""
    settings, ranges = config["matching"], config.get("correspondence_ranges", [])
    validate_ranges(ranges)
    run = Path(prepared["run_dir"])
    encoder = encoder or ClipEncoder(config.get("model_name", "openai/clip-vit-base-patch32"))
    finals, animatic, panels = prepared["frames"]["final"], prepared["frames"]["animatic"], prepared["panels"]
    if not panels and not animatic:
        raise ValueError("No usable evidence was extracted; check panel layout or video sampling")
    vectors = {"final": encoder.images(finals), "animatic": encoder.images(animatic),
               "storyboard": encoder.images(panels)}
    groups = {}
    for i, panel in enumerate(panels):
        item = panel["text"]
        if item.get("description"):
            groups.setdefault(item["text_group_id"], {"description": item["description"], "panels": []})["panels"].append(i)
    group_ids = list(groups)
    text_vectors = encoder.texts([groups[k]["description"] for k in group_ids]) if groups else None
    text_scores = vectors["final"] @ text_vectors.T if groups else None
    feature_cache = {}

    def structure(record):
        from .dual_retrieval import structure_feature
        path = record.get("keyframe_path") or record["panel_path"]
        if path not in feature_cache:
            feature_cache[path] = structure_feature(path)
        return feature_cache[path]

    candidates, decisions = [], []
    for kind, evidence in (("storyboard", panels), ("animatic", animatic)):
        if not evidence:
            continue
        matrix = vectors["final"] @ vectors[kind].T
        route_rows = []
        for fi, final in enumerate(finals):
            allowed = allowed_evidence(final, evidence, kind, ranges, settings["require_declared_ranges"])
            order = sorted(allowed, key=lambda i: (-float(matrix[fi, i]), evidence[i]["evidence_index"]))
            group_ranks = {}
            if kind == "storyboard" and groups:
                active_groups = [j for j, key in enumerate(group_ids)
                                 if any(i in allowed for i in groups[key]["panels"])]
                active_groups.sort(key=lambda j: -float(text_scores[fi, j]))
                group_ranks = {group_ids[j]: rank for rank, j in enumerate(active_groups, 1)}
            rows = []
            for rank, ei in enumerate(order[:max(settings["top_k"], settings["structure_candidate_limit"])], 1):
                item = evidence[ei]
                text = item.get("text", {})
                text_rank = group_ranks.get(text.get("text_group_id"))
                detail = {}
                if kind == "storyboard" and settings["use_structure"] and rank <= settings["structure_candidate_limit"]:
                    from .local_structure import local_support
                    detail = local_support(structure(item), structure(final))
                row = dict(id=f"final_{kind}:{fi + 1}:{item['evidence_index']}", route=f"final_{kind}",
                           final_index=fi + 1, final_timestamp_sec=final["timestamp_sec"],
                           final_path=final["keyframe_path"], evidence_index=item["evidence_index"],
                           evidence_path=item.get("keyframe_path") or item["panel_path"],
                           evidence_timestamp_sec=item.get("timestamp_sec"),
                           visual_similarity=float(matrix[fi, ei]), visual_rank=rank,
                           declared_range_ids=allowed[ei], description=text.get("description"),
                           text_group_id=text.get("text_group_id"), text_group_rank=text_rank,
                           shared_panel_count=text.get("shared_panel_count"),
                           text_similarity=float(text_scores[fi, group_ids.index(text["text_group_id"])])
                           if text_rank is not None else None,
                           text_supported=text_rank is not None and text_rank <= settings["text_top_k"],
                           structure=detail, structure_supported=False, neighbor_supported=False)
                if rank == 1:
                    row["runner_up_visual_similarity"] = float(matrix[fi, order[1]]) if len(order) > 1 else None
                rows.append(row)
            structure_order = sorted([r for r in rows if r["structure"].get("assessment") in
                                      ("partial_support", "structural_support")],
                                     key=lambda r: -r["structure"]["oriented_coverage"])
            for rank, row in enumerate(structure_order, 1):
                row["structure_rank"] = rank
                row["structure_supported"] = rank <= settings["structure_top_k"]
            if kind == "storyboard":
                rows = rerank_with_text(rows, settings)
            route_rows.append(rows[:settings["top_k"]])
        for fi, rows in enumerate(route_rows):
            for row in rows:
                neighbors = [j for j in range(max(0, fi - settings["neighbor_radius"]),
                                               min(len(finals), fi + settings["neighbor_radius"] + 1)) if j != fi]
                row["neighbor_supported"] = any(route_rows[j] and
                    route_rows[j][0]["evidence_index"] == row["evidence_index"] for j in neighbors)
            decision = select_top1(rows, settings)
            decision.update(route=f"final_{kind}", final_index=fi + 1,
                            final_timestamp_sec=finals[fi]["timestamp_sec"], decision_source="automatic")
            if not rows:
                decision["reason"] = "no_extracted_evidence_in_declared_range"
                if settings["require_declared_ranges"] and not any(r["evidence_type"] == kind for r in ranges):
                    decision.update(status="not_evaluated", reason="no_declared_range_for_this_material")
            decisions.append(decision)
            candidates.extend(rows)
        progress(f"Retrieved Final to {kind}")
    # Supplementary relation only; it cannot override either primary route.
    supplementary = []
    if animatic and panels:
        matrix = vectors["animatic"] @ vectors["storyboard"].T
        for ai, values in enumerate(matrix):
            for rank, pi in enumerate(np.argsort(-values, kind="stable")[:settings["top_k"]], 1):
                supplementary.append(dict(animatic_index=animatic[ai]["evidence_index"],
                    storyboard_index=panels[int(pi)]["evidence_index"], visual_rank=rank,
                    visual_similarity=float(values[pi]), status="supplementary_candidate"))
    # Repeat limits flag uncertainty without changing the independently ranked winner.
    for route in ("final_storyboard", "final_animatic"):
        previous, count = None, 0
        lookup = {r["id"]: r for r in candidates}
        for decision in (d for d in decisions if d["route"] == route):
            selected = lookup.get(decision.get("selected_candidate_id"))
            key = selected["evidence_index"] if selected else None
            count = count + 1 if key is not None and key == previous else 1
            previous = key
            if selected and count > settings["max_consecutive"]:
                decision["continuous_reuse_warning"] = True
            if (selected and count > settings["max_consecutive"]
                    and settings.get("acceptance_mode", "strict") == "strict"):
                decision.update(status="requires_review", reason="consecutive_evidence_limit_exceeded",
                                selected_candidate_id=None)
    result = dict(schema_version="cs55-system-v1", candidates=candidates, decisions=decisions,
                  supplementary=supplementary, run_dir=str(run),
                  range_semantics="submitter_declared_correspondence_not_ground_truth",
                  thresholds_calibrated=False)
    save_json(run / "result.json", result)
    apply_reviews(run)
    return result


def inspect_provenance(config, prepared, progress=print):
    progress("Inspecting native provenance evidence")
    assets = {role: inspect_asset_basics(role, path) for role, path in prepared["assets"].items()}
    projects = collect_project_file_evidence(config)
    for role, asset in assets.items():
        asset["project_file"] = projects[role]
        asset["editing_history"] = build_editing_history(asset["timestamps"], asset["c2pa_manifest"],
                                                        asset["software"], asset["project_file"])
        asset["provenance_summary"] = build_provenance_summary(
            asset["file_hash"], asset["metadata"], asset["timestamps"], asset["c2pa_manifest"],
            asset["software"], asset["project_file"], asset["editing_history"])
    summary = {role: item["provenance_summary"] for role, item in assets.items()}
    run = Path(prepared["run_dir"])
    for name, value in (("provenance", assets), ("provenance_summary", summary),
                        ("provenance_scores", provenance_scores(summary)),
                        ("timestamp_comparisons", timestamp_comparisons(assets))):
        save_json(run / f"{name}.json", value)
    return summary


def _scores(finals, rows):
    supported = {r["final_index"] for r in rows}
    order = []
    for route in ("final_storyboard", "final_animatic"):
        selected = sorted((r for r in rows if r["route"] == route), key=lambda r: r["final_index"])
        concordant = discordant = tied = 0
        for i, left in enumerate(selected):
            for right in selected[i + 1:]:
                delta = right["evidence_index"] - left["evidence_index"]
                concordant += int(delta > 0)
                discordant += int(delta < 0)
                tied += int(delta == 0)
        comparable = concordant + discordant
        order.append(dict(route=route, confirmed_pair_count=len(selected),
                          concordant_pair_count=concordant, discordant_pair_count=discordant,
                          tied_pair_count=tied, comparable_pair_count=comparable,
                          score=round(100 * concordant / comparable, 2)
                          if comparable and len(selected) >= 3 else None,
                          index_sequence=[r["evidence_index"] for r in selected]))
    eligible = [r for r in order if r["score"] is not None]
    comparable = sum(r["comparable_pair_count"] for r in eligible)
    concordant = sum(r["concordant_pair_count"] for r in eligible)
    sequence = 100 * concordant / comparable if comparable else None
    coverage = 100 * len(supported) / len(finals) if finals else None
    overall = (2 * coverage * sequence / (coverage + sequence) if coverage + sequence else 0.) \
        if coverage is not None and sequence is not None else None
    return dict(total_final_frames=len(finals), supported_final_frames=len(supported),
                visual_support_score=round(coverage, 2) if coverage is not None else None,
                sequence_consistency_score=round(sequence, 2) if sequence is not None else None,
                overall_evidence_score=round(overall, 2) if overall is not None else None,
                route_order=order, coverage_denominator="all_retained_sampled_final_frames",
                formulas=dict(visual="supported / all_retained_final_frames * 100",
                              sequence="concordant / (concordant + discordant) * 100",
                              overall="harmonic_mean(visual, sequence)"))


def apply_reviews(run, reviews=None):
    """Apply optional human overrides; automatic and human scores stay separate."""
    run = Path(run)
    result = json.loads((run / "result.json").read_text())
    prepared = json.loads((run / "prepared.json").read_text())
    review_path = run / "reviews.json"
    if reviews is None:
        reviews = json.loads(review_path.read_text()) if review_path.exists() else []
    candidates = {r["id"]: r for r in result["candidates"]}
    decisions = {(d["route"], d["final_index"]): dict(d) for d in result["decisions"]}
    seen = set()
    for review in reviews:
        key = (review["route"], review["final_index"])
        if key in seen or key not in decisions:
            raise ValueError("Each existing Final/route can have only one review")
        seen.add(key)
        decision = review["decision"]
        candidate_id = review.get("candidate_id")
        if decision not in ("matched", "unmatched", "pending"):
            raise ValueError("Invalid human decision")
        if decision == "matched" and (candidate_id not in candidates or
                (candidates[candidate_id]["route"], candidates[candidate_id]["final_index"]) != key):
            raise ValueError("Selected candidate does not belong to this Final/route")
        decisions[key].update(status="human_confirmed" if decision == "matched" else
                             "insufficient_evidence" if decision == "unmatched" else "requires_review",
                             selected_candidate_id=candidate_id if decision == "matched" else None,
                             decision_source="human", reason=review.get("reason", decision))
    selected = [dict(candidates[d["selected_candidate_id"]], decision_source=d["decision_source"],
                     decision_status=d["status"]) for d in decisions.values() if d.get("selected_candidate_id")]
    final_support, unmatched, pending = [], [], []
    for i, frame in enumerate(prepared["frames"]["final"], 1):
        routes = [d for d in decisions.values() if d["final_index"] == i]
        supports = [r for r in selected if r["final_index"] == i]
        entry = dict(final_index=i, final_path=frame["keyframe_path"],
                     status="supported" if supports else "pending" if any(
                         d["status"] == "requires_review" for d in routes) else "insufficient_evidence",
                     selected_evidence=supports, routes=routes)
        final_support.append(entry)
        if entry["status"] == "pending":
            pending.append(entry)
        elif entry["status"] == "insufficient_evidence":
            unmatched.append(entry)
    human = [r for r in selected if r["decision_source"] == "human"]
    scores = dict(human_confirmed=_scores(prepared["frames"]["final"], human),
                  provisional_and_human=_scores(prepared["frames"]["final"], selected),
                  interpretation="Automatic decisions remain provisional; scores do not measure retrieval accuracy.")
    diagnostics = {}
    for scope in ("human_confirmed", "provisional_and_human"):
        diagnostics[scope] = []
        for order in scores[scope]["route_order"]:
            sequence = order["index_sequence"]
            diagnostics[scope].append(dict(route=order["route"], index_sequence=sequence,
                adjacent_events=[dict(previous=a, current=b, delta=b-a,
                    relation="backtrack" if b < a else "repeat" if b == a else
                             "forward_gap" if b > a + 1 else "forward")
                    for a, b in zip(sequence, sequence[1:])],
                pairwise_inversion_count=order["discordant_pair_count"],
                interpretation="Backtracks and gaps require context; they may reflect a wrong match or sampling."))
    triangle = []
    supplementary = {(r["animatic_index"], r["storyboard_index"]): r for r in result["supplementary"]}
    for final in final_support:
        by_route = {r["route"]: r for r in final["selected_evidence"]}
        if "final_storyboard" in by_route and "final_animatic" in by_route:
            key = (by_route["final_animatic"]["evidence_index"], by_route["final_storyboard"]["evidence_index"])
            row = supplementary.get(key)
            triangle.append(dict(final_index=final["final_index"], animatic_index=key[0],
                storyboard_index=key[1], supplementary_candidate_present=bool(row),
                supplementary_rank=row["visual_rank"] if row else None,
                status="supporting_context_only", affects_acceptance=False))
    for name, value in (("reviews", reviews), ("matched_list", selected), ("unmatched_list", unmatched),
                        ("pending_list", pending), ("final_support", final_support),
                        ("effective_decisions", list(decisions.values())), ("evidence_scores", scores),
                        ("sequence_index_diagnostics", diagnostics), ("triangle_diagnostics", triangle)):
        save_json(run / f"{name}.json", value)
    return scores


def run_pipeline(config_path):
    config = load_config(config_path)
    prepared = prepare(config)
    result = retrieve(config, prepared)
    if config.get("inspect_provenance", True):
        inspect_provenance(config, prepared)
    return result

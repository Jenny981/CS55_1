"""Independent provenance rubrics retained from the review application."""
from datetime import datetime, timezone

def timestamp_comparisons(provenance):
    """Compare each evidence asset timestamp with Final without treating it as proof."""
    fields = (('embedded_creation_time', 'media', 'creation_time', 'declared'), ('embedded_modification_time', 'media', 'modification_time', 'declared'), ('filesystem_creation_time', 'filesystem', 'created_at', 'observed'), ('filesystem_modification_time', 'filesystem', 'modified_at', 'observed'))

    def parse_timestamp(value):
        if value in (None, ''):
            return None
        try:
            parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        except (TypeError, ValueError):
            return None
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    final_timestamps = provenance.get('final', {}).get('timestamps', {})
    output = []
    for evidence_name in ('storyboard', 'animatic'):
        if evidence_name not in provenance or 'final' not in provenance:
            continue
        evidence_timestamps = provenance[evidence_name].get('timestamps', {})
        comparisons = []
        for label, section, key, evidence_type in fields:
            evidence_value = evidence_timestamps.get(section, {}).get(key)
            final_value = final_timestamps.get(section, {}).get(key)
            evidence_time = parse_timestamp(evidence_value)
            final_time = parse_timestamp(final_value)
            if evidence_time is None or final_time is None:
                score = None
                status = 'not_comparable'
                delta_seconds = None
                reason = 'One or both timestamps are missing or cannot be parsed.'
            else:
                delta_seconds = (final_time - evidence_time).total_seconds()
                if delta_seconds >= 0:
                    score = 100.0
                    status = 'evidence_not_later_than_final'
                    reason = 'The observed evidence timestamp is not later than the corresponding Final timestamp.'
                else:
                    score = 0.0
                    status = 'evidence_later_than_final_requires_review'
                    reason = 'The observed evidence timestamp is later than the corresponding Final timestamp and requires review.'
            comparisons.append({'timestamp_type': label, 'record_type': evidence_type, 'evidence_value': evidence_value, 'final_value': final_value, 'delta_seconds_final_minus_evidence': delta_seconds, 'score': score, 'status': status, 'reason': reason})
        output.append({'relationship': f'{evidence_name}_to_final', 'evidence_asset': evidence_name, 'final_asset': 'final', 'comparisons': comparisons, 'limitations': ['Filesystem timestamps can change when files are copied, downloaded, or restored.', 'Embedded timestamps are self-declared metadata unless independently signed.', 'Chronological order is supporting context, not proof of authorship or authenticity.']})
    return {'method': 'evidence_final_timestamp_comparison_v1', 'relationships': output, 'score_interpretation': 'Each comparable timestamp receives 100 when evidence is not later than Final, 0 when it is later, and N/A when unavailable. Scores are not aggregated.'}

def provenance_scores(provenance_summary):
    """Score every provenance indicator with an explicit check-level rubric."""
    rubrics = {'file_integrity': {'sha256_computed': (70, True), 'bytes_hashed': (30, True)}, 'c2pa_provenance': {'manifest_present': (20, True), 'signature_valid': (35, True), 'signing_credential_trusted': (20, True), 'no_validation_errors': (15, True), 'validation_warnings': (10, True)}, 'source_project': {'candidate_found': (25, True), 'project_hash_available': (25, True), 'relationship_verified': (50, True)}, 'editing_ai_transparency': {'c2pa_actions_present': (20, True), 'declared_history_events': (20, True), 'timestamps_available': (20, True), 'software_identified': (20, True), 'metadata_extracted': (20, True)}}
    assets = {}
    for asset_name, item in provenance_summary.items():
        indicators = item.get('indicators', {})
        indicator_scores = {}
        for indicator_id, indicator in indicators.items():
            if not isinstance(indicator, dict):
                continue
            checks_by_name = {check.get('name'): check for check in indicator.get('checks', []) if isinstance(check, dict)}
            rubric = rubrics.get(indicator_id, {})
            components = []
            for check_name, (maximum_points, applicable) in rubric.items():
                check = checks_by_name.get(check_name, {})
                passed = check.get('result') is True
                components.append({'check': check_name, 'applicable': applicable, 'passed': passed, 'points_awarded': float(maximum_points if passed else 0), 'maximum_points': float(maximum_points), 'observed_value': check.get('value'), 'source': check.get('source'), 'explanation': check.get('explanation')})
            score = sum((component['points_awarded'] for component in components))
            maximum = sum((component['maximum_points'] for component in components if component['applicable']))
            if indicator_id == 'c2pa_provenance' and (not checks_by_name.get('manifest_present', {}).get('result')):
                score = 0.0
                gate_reason = 'No manifest was found, so validation-cleanliness checks cannot earn C2PA points.'
            else:
                gate_reason = None
            indicator_scores[indicator_id] = {'label': indicator.get('label', indicator_id), 'score': round(100.0 * score / maximum, 2) if maximum else None, 'points_awarded': score, 'maximum_points': maximum, 'available': indicator.get('available') is True, 'reason': indicator.get('reason'), 'gate_reason': gate_reason, 'components': components, 'unscored_context_checks': [check for name, check in checks_by_name.items() if name not in rubric]}
        assets[asset_name] = {'status': item.get('status'), 'review_required': bool(item.get('conflicts')), 'indicator_scores': indicator_scores}
    return {'method': 'independent_weighted_check_rubrics_v2', 'score_interpretation': 'Each indicator is scored independently from its documented checks. No aggregate provenance score is calculated.', 'rubric_basis': {'file_integrity': 'Digest completion is primary; successful byte reading is supporting evidence.', 'c2pa_provenance': 'Manifest presence opens the gate; signature validity and credential trust carry the most weight.', 'source_project': 'A candidate alone is weak; an explicitly verified relationship carries the most weight.', 'editing_ai_transparency': 'Five independent forms of process context contribute equally. AI absence is not penalised.'}, 'assets': assets, 'limitations': ['Indicator scores measure evidence quality and availability, not authenticity probability.', 'A low score means supporting provenance evidence is limited; it does not prove fabrication.', 'The four indicator scores must not be added or averaged into a single provenance score.', 'Conflicts are reported separately for human review.']}
